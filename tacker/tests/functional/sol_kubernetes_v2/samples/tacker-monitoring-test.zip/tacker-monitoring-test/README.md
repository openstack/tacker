# pseudo external monitoring tool for testing.

## setup and run

```
docker build -t tacker-monitoring-test .
docker run -v ${PWD}/src:/work/src -v ${PWD}/rules:/etc/prometheus/rules -p 55555:55555 -p 50022:22 -e TEST_REMOTE_URI="http://<nfvo_addr>:<port>" -it tacker-monitoring-test
```

```
(under proxy environment)
sudo docker build --build-arg PROXY=$http_proxy -t tacker-monitoring-test .
docker run -v ${PWD}/src:/work/src -v ${PWD}/rules:/etc/prometheus/rules -p 55555:55555 -p 50022:22 -e TEST_REMOTE_URI="http://<nfvo_addr>:<port>" -it tacker-monitoring-test
```
