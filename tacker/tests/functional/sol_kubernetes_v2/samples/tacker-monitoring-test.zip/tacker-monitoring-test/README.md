```
docker builld -t tacker-monitoring-test .
docker run -v ${PWD}/src:/work/src -v ${PWD}/rules:/etc/prometheus/rules -p 55555:55555 -p 50022:22 -e TEST_REMOTE_URI="http://<ip_addr>:55555" -it tacker-monitoring-test
```

