#!/bin/bash

service ssh start

python3 /work/src/testserver.py
